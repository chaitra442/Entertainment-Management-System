<!DOCTYPE html>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>cems</title>
<?php require 'utils/styles.php'; ?><!--css links. file found in utils folder-->
</head>
<style>

/* Large rounded green border */
hr.blueline {
  border: 10px solid #00004d;
  border-radius: 5px;
}

#bj
{
  font-size: 22px;
}
</style>



  <?php require 'utils/header.php'; ?>
  <hr class="blueline">
  <div class="col-md-12">
  
<h1>About Us</h1>

<p>  Our mission is simple: to create memorable experiences that bring people together. With creativity, passion, and dedication, we craft events that inspire, entertain, and foster connections within our community.
                  .</p>

</div>
<hr class="blueline">
</body>

 <?php require 'utils/footer.php'; ?>

</html>